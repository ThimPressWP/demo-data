<?php

function thim_child_enqueue_styles() {
	wp_enqueue_style( 'thim-child-style', get_stylesheet_uri() );
}

add_action( 'wp_enqueue_scripts', 'thim_child_enqueue_styles', 100 );