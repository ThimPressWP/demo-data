<?php

function thim_child_enqueue_styles(){
	if (is_rtl()) {
		wp_enqueue_style('thim-parent-style', get_template_directory_uri() . '/style-rtl.css', array(), THIM_THEME_VERSION);
		wp_enqueue_style('thim-style', get_stylesheet_directory_uri() . '/style.css', ['thim-parent-style']);
	} else {
		wp_enqueue_style('thim-parent-style', get_template_directory_uri() . '/style.css', array(), THIM_THEME_VERSION);
	}
}

add_action('wp_enqueue_scripts', 'thim_child_enqueue_styles', 99);