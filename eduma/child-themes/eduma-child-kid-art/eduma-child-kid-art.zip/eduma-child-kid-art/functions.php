<?php

function thim_child_enqueue_styles() {
    wp_enqueue_style( 'thim-parent-style', get_template_directory_uri() . '/style.css', array(), THIM_THEME_VERSION );
 	wp_enqueue_script( 'thim_child_script', get_stylesheet_directory_uri() . '/js/child_script.js', array( 'jquery' ), THIM_THEME_VERSION );
}
add_action( 'wp_enqueue_scripts', 'thim_child_enqueue_styles', 1000 );

load_theme_textdomain( 'eduma-child-kid-art', get_stylesheet_directory() . '/languages' );

add_filter( 'body_class', 'thim_kid_art_custom_class' );
function thim_kid_art_custom_class( $classes ) {
	$classes[] = 'thim-child-kid-art';
	return $classes;
}

/* Replace courses meta */
function thim_add_course_meta( $meta_box ) {
    $fields             = array();
    $fields[]           = array(
        'name' => esc_html__( 'Duration Info', 'eduma-child-kid-art' ),
        'id'   => 'thim_course_duration',
        'type' => 'text',
        'desc' => esc_html__( 'Display duration info', 'eduma-child-kid-art' ),
        'std'  => esc_html__( '30 hours', 'eduma-child-kid-art' )
    );
    $fields[]           = array(
        'name' => esc_html__( 'Time', 'eduma-child-kid-art' ),
        'id'   => 'thim_course_time',
        'type' => 'text',
        'desc' => esc_html__( 'Show Time start and time end in course', 'eduma-child-kid-art' ),
    );
    $fields[] = array(
        'name' => esc_html__( 'Day of Week', 'eduma-child-kid-art' ),
        'id'   => 'thim_course_day_of_week',
        'type' => 'text',
        'desc' => esc_html__( 'Show Day of Week Course', 'eduma-child-kid-art' ),
    );
    $fields[]           = array(
        'name' => esc_html__( 'Available Seats', 'eduma-child-kid-art' ),
        'id'   => 'thim_course_available_seats',
        'type' => 'number',
        'desc' => esc_html__( 'Enter available seats', 'eduma-child-kid-art' ),
        'std'  => esc_html__( '10', 'eduma-child-kid-art' )
    );
    $fields[]           = array(
        'name' => esc_html__( 'Skill Levels', 'eduma-child-kid-art' ),
        'id'   => 'thim_course_skill_levels',
        'type' => 'text',
        'desc' => esc_html__( 'Display skill levels', 'eduma-child-kid-art' ),
        'std'  => esc_html__( 'All level', 'eduma-child-kid-art' )
    );
    $fields[]           = array(
        'name' => esc_html__( 'Price', 'eduma-child-kid-art' ),
        'id'   => 'thim_course_price',
        'type' => 'text',
        'desc' => esc_html__( 'Enter course price', 'eduma-child-kid-art' ),
        'std'  => esc_html__( '$50', 'eduma-child-kid-art' )
    );
    $fields[]           = array(
        'name' => esc_html__( 'Unit', 'eduma-child-kid-art' ),
        'id'   => 'thim_course_unit_price',
        'type' => 'text',
        'desc' => esc_html__( 'Enter unit, for example, p/h, person/hour', 'eduma-child-kid-art' ),
        'std'  => esc_html__( 'p/h', 'eduma-child-kid-art' )
    );
    $fields[]           = array(
        'name' => esc_html__( 'Media Intro', 'eduma' ),
        'id'   => 'thim_course_media_intro',
        'type' => 'textarea',
        'desc' => esc_html__( 'Enter media intro', 'eduma' ),
    );
    $meta_box['fields'] = $fields;
    return $meta_box;
}

//Remove tab assessment & payment from LP 2.1.3
add_filter( 'learn_press_lp_course_tabs', 'thim_remove_tabs_course' );
function thim_remove_tabs_course( $tabs ) {
    if ( !empty( $tabs ) ) {
        foreach ( $tabs as $tab_id => $tab ) {
            if ( !empty( $tab->meta_box ) && is_array( $tab->meta_box ) ) {
                $id = $tab->meta_box['id'];
                if ( !empty( $id ) ) {
                    if ( in_array( $id, array( 'course_payment', 'course_assessment' ) ) ) {
                        unset( $tabs[$tab_id] );
                    }
                }
            }
        }
    }
    return $tabs;
}
function thim_child_manage_course_columns( $columns ) {
    unset( $columns['price'] );
    $keys   = array_keys( $columns );
    $values = array_values( $columns );
    $pos    = array_search( 'sections', $keys );
    if ( $pos !== false ) {
        array_splice( $keys, $pos + 1, 0, array( 'thim_price' ) );
        array_splice( $values, $pos + 1, 0, __( 'Price', 'eduma-child-kid-art' ) );
        $columns = array_combine( $keys, $values );
    } else {
        $columns['thim_price'] = __( 'Price', 'eduma-child-kid-art' );
    }
    return $columns;
}
add_filter( 'manage_lp_course_posts_columns', 'thim_child_manage_course_columns' );
function thim_child_manage_course_columns_content( $column ) {
    global $post;
    switch ( $column ) {
        case 'thim_price':
            $price      = get_post_meta( $post->ID, 'thim_course_price', true );
            $unit_price = get_post_meta( $post->ID, 'thim_course_unit_price', true );
            echo $price;
            if($price != '' && $unit_price != ''){
                echo '/';
            } else{
                echo ' ';
            }
            echo $unit_price;
    }
}
add_filter( 'manage_lp_course_posts_custom_column', 'thim_child_manage_course_columns_content' );


/**
 * Back to top
 */
if ( !function_exists( 'thim_back_to_top' ) ) {
    function thim_back_to_top() {
        if ( get_theme_mod( 'thim_show_to_top', false ) ) { ?>
            <a href="#" id="back-to-top">
                <i class="ion-ios-arrow-thin-up" aria-hidden="true"></i>
            </a>
            <?php
        }
    }
}
add_action( 'thim_end_wrapper_container', 'thim_back_to_top' );

/**
 * Create function course info
 */
function thim_archive_course_info() {
    $time_course = get_post_meta(get_the_ID(),'thim_course_time',true);
    $day_of_week = get_post_meta(get_the_ID(),'thim_course_day_of_week',true);
    ?>
        <ul class="course-info">
            <li class="info-item"><span><?php echo esc_html('Time: ','eduma-child-kid-art')?></span> <?php echo  esc_html($time_course); ?> </li>
            <li class="info-item"><span><?php echo esc_html('Days of Week: ','eduma-child-kid-art')?></span> <?php echo  esc_html($day_of_week); ?> </li>
        </ul>
    <?php
}
add_action('learn_press_after_the_title','thim_archive_course_info');

/**
 * Display related courses
 */
if ( ! function_exists( 'thim_related_courses' ) ) {
    function thim_related_courses() {
        $related_courses    = thim_get_related_courses( 3 );
        $theme_options_data = get_theme_mods();
        $style_content      = isset( $theme_options_data['thim_layout_content_page'] ) ? $theme_options_data['thim_layout_content_page'] : 'normal';

        if ( $related_courses ) {
            $layout_grid = get_theme_mod( 'thim_learnpress_cate_layout_grid', '' );
            $cls_layout  = ( $layout_grid != '' && $layout_grid != 'layout_courses_1' ) ? ' cls_courses_2' : ' ';
            ?>
            <div class="thim-ralated-course <?php echo $cls_layout; ?>">

                <?php if ( $style_content == 'new-1' ) { ?>
                    <div class="sc_heading clone_title  text-left">
                        <h2 class="title"><?php esc_html_e( 'You May Like', 'eduma' ); ?></h2>
                        <div class="clone"><?php esc_html_e( 'You May Like', 'eduma' ); ?></div>
                    </div>
                <?php } else { ?>
                    <h3 class="related-title">
                        <?php esc_html_e( 'You May Like', 'eduma' ); ?>
                    </h3>
                <?php } ?>

                <div class="thim-course-grid">
                    <div class="thim-carousel-wrapper" data-visible="3" data-itemtablet="2" data-itemmobile="1"
                         data-pagination="1">
                        <?php foreach ( $related_courses as $course_item ) : ?>
                            <?php
                            $course      = learn_press_get_course( $course_item->ID );
                            $time_course = get_post_meta($course_item->ID,'thim_course_time',true);
                            $day_of_week = get_post_meta($course_item->ID,'thim_course_day_of_week',true);
                            $price       = get_post_meta( $course_item->ID, 'thim_course_price', true );
                            $unit_price  = get_post_meta( $course_item->ID, 'thim_course_unit_price', true );
                            $is_required                = $course->is_required_enroll();
                            $course_des                 = get_post_meta( $course_item->ID, '_lp_coming_soon_msg', true );
                            $course_item_excerpt_length = get_theme_mod( 'thim_learnpress_excerpt_length', 25 );
                            ?>
                            <article class="lpr_course">
                                <div class="course-item">
                                    <div class="course-thumbnail">
                                        <a class="thumb" href="<?php echo get_the_permalink( $course_item->ID ); ?>">
                                            <?php
                                            if ( $layout_grid != '' && $layout_grid != 'layout_courses_1' ) {
                                                echo thim_get_feature_image( get_post_thumbnail_id( $course_item->ID ), 'full', 320, 220, get_the_title( $course_item->ID ) );
                                            } else {
                                                echo thim_get_feature_image( get_post_thumbnail_id( $course_item->ID ), 'full', 450, 450, get_the_title( $course_item->ID ) );
                                            }
                                            ?>
                                        </a>
                                        <?php do_action( 'thim_inner_thumbnail_course' ); ?>
                                        <?php echo '<a class="course-readmore" href="' . esc_url( get_the_permalink( $course_item->ID ) ) . '">' . esc_html__( 'Read More', 'eduma' ) . '</a>'; ?>
                                    </div>
                                    <div class="thim-course-content">
                                        <div class="course-author">
                                            <?php echo get_avatar( $course_item->post_author, 40 ); ?>
                                            <div class="author-contain">
                                                <div class="value">
                                                    <a href="<?php echo esc_url( learn_press_user_profile_link( $course_item->post_author ) ); ?>">
                                                        <?php echo get_the_author_meta( 'display_name', $course_item->post_author ); ?>
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                        <h2 class="course-title">
                                            <a rel="bookmark"
                                               href="<?php echo get_the_permalink( $course_item->ID ); ?>"><?php echo esc_html( $course_item->post_title ); ?></a>
                                        </h2> <!-- .entry-header -->

                                        <ul class="course-info">
                                            <li class="info-item"><span><?php echo esc_html('Time: ','eduma-child-kid-art')?></span> <?php echo  esc_html($time_course); ?> </li>
                                            <li class="info-item"><span><?php echo esc_html('Days of Week: ','eduma-child-kid-art')?></span> <?php echo  esc_html($day_of_week); ?> </li>
                                        </ul>

                                        <div class="course-meta">
                                            <div class="course-price">
                                                <?php if($price): ?><div class="value "><?php echo esc_html($price); ?></div><?php endif; ?>
                                                <?php if($unit_price): ?><span class="unit-price">/<?php echo esc_html($unit_price); ?></span><?php endif; ?>
                                            </div>
                                        </div>

                                        <?php if ( thim_plugin_active( 'learnpress-coming-soon-courses/learnpress-coming-soon-courses.php' ) && learn_press_is_coming_soon( $course_item->ID ) ): ?>
                                            <?php if ( intval( $course_item_excerpt_length ) && $course_des ): ?>
                                                <div class="course-description">
                                                    <?php echo wp_trim_words( $course_des, $course_item_excerpt_length ); ?>
                                                </div>
                                            <?php endif; ?>

                                            <div class="message message-warning learn-press-message coming-soon-message">
                                                <?php esc_html_e( 'Coming soon', 'eduma' ) ?>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </article>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
            <?php
        }
    }
}

/* Course info*/
function thim_course_info() {

    $course_id = get_the_ID();

    $duration           = get_post_meta( $course_id, 'thim_course_duration', true );
    $time               = get_post_meta( $course_id, 'thim_course_time', true );
    $day_of_week        = get_post_meta( $course_id, 'thim_course_day_of_week', true );
    $available_seats    = get_post_meta( $course_id, 'thim_course_available_seats', true );
    $skill_level        = get_post_meta( $course_id, 'thim_course_skill_levels', true );
    $thim_options       = get_theme_mods();

    $category = wp_get_post_terms( $course_id, 'course_category' );

    $cat_name = $category[0]->name;

    ?>
    <div class="thim-course-info">
        <h3 class="title"><?php esc_html_e( 'Course Features', 'eduma-child-kid-art' ); ?></h3>
        <ul>
            <li class="duration-feature">
                <span class="label"><i class="fa fa-clock-o"></i> <?php esc_html_e( 'Duration', 'eduma-child-kid-art' ); ?></span>
                <span class="value"><?php echo esc_html( $duration ); ?></span>
            </li>
            <li class="time-feature">
                <span class="label"><i class="fa fa-bell-o"></i> <?php esc_html_e( 'Time', 'eduma-child-kid-art' ); ?></span>
                <span class="value"><?php echo esc_html( $time ); ?></span>

            </li>
            <li class="day-of-week-feature">
                <span class="label"><i class="fa fa-calendar-o"></i> <?php esc_html_e( 'Day of week', 'eduma-child-kid-art' ); ?></span>
                <span class="value"><?php echo esc_html( $day_of_week ); ?></span>

            </li>
            <li class="level-feature">
                <span class="label"> <i class="fa fa-level-up"></i> <?php esc_html_e( 'Skill level', 'eduma-child-kid-art' ); ?></span>
                <span class="value"><?php echo esc_html( $skill_level ); ?></span>
            </li>
            <li class="available-feature">
                <span class="label"><i class="fa fa-user-plus"></i> <?php esc_html_e( 'Available Seats', 'eduma-child-kid-art' ); ?></span>
                <span class="value"><?php echo esc_html( $available_seats ); ?></span>
            </li>

        </ul>
        <?php
        if ( !empty( $thim_options['thim_learnpress_timetable_link'] ) ) {
            echo '<div class="text-center"><a class="thim-timetable-link" target="_blank" href="' . esc_url( $thim_options['thim_learnpress_timetable_link'] ) . '">' . esc_html( 'Courses Schedules', 'eduma-child-kid-art' ) . '</a></div>';
        }
        ?>
    </div>
    <?php
}

/* form register in single course */
function thim_register_course() {
    if(is_singular('lp_course')){
        ?>
            <div id="contact-form-registration" class="">
                <?php
                $thim_options = get_theme_mods();
                $contact_form = $thim_options['thim_learnpress_shortcode_contact'];
                $contact = str_replace('&quot;','"',$contact_form);

                if ( ! empty( $contact_form ) ) {
                    echo do_shortcode( $contact );
                }

                ?>
            </div>
        <?php
    }
}
add_action('thim_end_wrapper_container','thim_register_course');
