<?php

function thim_child_enqueue_styles() {
	if ( is_multisite() ) {
		wp_enqueue_style( 'thim-child-style', get_stylesheet_uri(), array(), THIM_THEME_VERSION );
	} else {
		wp_enqueue_style( 'thim-parent-style', get_template_directory_uri() . '/style.css', array(), THIM_THEME_VERSION );
	}

	wp_enqueue_script( 'thim_child_script', get_stylesheet_directory_uri() . '/js/child_script.js', array( 'jquery' ), THIM_THEME_VERSION );
}
add_action( 'wp_enqueue_scripts', 'thim_child_enqueue_styles', 1000 );

load_theme_textdomain( 'eduma-child', get_stylesheet_directory() . '/languages' );

add_filter( 'body_class', 'thim_instructor_custom_class' );
function thim_instructor_custom_class( $classes ) {
	$classes[] = 'thim-child-new-art';
	return $classes;
}

//Replace courses meta
function thim_add_course_meta( $meta_box ) {
	$fields             = array();
	$fields[]           = array(
		'name' => esc_html__( 'Duration Info', 'eduma-child' ),
		'id'   => 'thim_course_duration',
		'type' => 'text',
		'desc' => esc_html__( 'Display duration info', 'eduma-child' ),
		'std'  => esc_html__( '30 hours', 'eduma-child' )
	);

	$fields[]           = array(
		'name' => esc_html__( 'Time', 'eduma-child' ),
		'id'   => 'thim_course_time',
		'type' => 'text',
		'desc' => esc_html__( 'Show Time start and time end in course', 'eduma-child' ),
	);

	$fields[] = array(
		'name' => esc_html__( 'Day of Week', 'eduma-child' ),
		'id'   => 'thim_course_day_of_week',
		'type' => 'text',
		'desc' => esc_html__( 'Show Day of Week Course', 'eduma-child' ),
	);

	$fields[]           = array(
		'name' => esc_html__( 'Available Seats', 'eduma-child' ),
		'id'   => 'thim_course_available_seats',
		'type' => 'number',
		'desc' => esc_html__( 'Enter available seats', 'eduma-child' ),
		'std'  => esc_html__( '10', 'eduma-child' )
	);

	$fields[]           = array(
		'name' => esc_html__( 'Skill Levels', 'eduma-child' ),
		'id'   => 'thim_course_skill_levels',
		'type' => 'text',
		'desc' => esc_html__( 'Display skill levels', 'eduma-child' ),
		'std'  => esc_html__( 'All level', 'eduma-child' )
	);

	$fields[]           = array(
		'name' => esc_html__( 'Price', 'eduma-child' ),
		'id'   => 'thim_course_price',
		'type' => 'text',
		'desc' => esc_html__( 'Enter course price', 'eduma-child' ),
		'std'  => esc_html__( '$50', 'eduma-child' )
	);
	$fields[]           = array(
		'name' => esc_html__( 'Unit', 'eduma-child' ),
		'id'   => 'thim_course_unit_price',
		'type' => 'text',
		'desc' => esc_html__( 'Enter unit, for example, p/h, person/hour', 'eduma-child' ),
		'std'  => esc_html__( 'p/h', 'eduma-child' )
	);
	$fields[]           = array(
		'name' => esc_html__( 'Media Intro', 'eduma' ),
		'id'   => 'thim_course_media_intro',
		'type' => 'textarea',
		'desc' => esc_html__( 'Enter media intro', 'eduma' ),
	);
	$meta_box['fields'] = $fields;

	return $meta_box;
}

//Remove tab assessment & payment from LP 2.1.3
add_filter( 'learn_press_lp_course_tabs', 'thim_remove_tabs_course' );
function thim_remove_tabs_course( $tabs ) {
	if ( !empty( $tabs ) ) {
		foreach ( $tabs as $tab_id => $tab ) {
			if ( !empty( $tab->meta_box ) && is_array( $tab->meta_box ) ) {
				$id = $tab->meta_box['id'];
				if ( !empty( $id ) ) {
					if ( in_array( $id, array( 'course_payment', 'course_assessment' ) ) ) {
						unset( $tabs[$tab_id] );
					}
				}
			}
		}
	}
	return $tabs;
}

function thim_child_manage_course_columns( $columns ) {
	unset( $columns['price'] );
	$keys   = array_keys( $columns );
	$values = array_values( $columns );
	$pos    = array_search( 'sections', $keys );
	if ( $pos !== false ) {
		array_splice( $keys, $pos + 1, 0, array( 'thim_price' ) );
		array_splice( $values, $pos + 1, 0, __( 'Price', 'eduma' ) );
		$columns = array_combine( $keys, $values );
	} else {
		$columns['thim_price'] = __( 'Price', 'eduma' );
	}
	return $columns;
}

add_filter( 'manage_lp_course_posts_columns', 'thim_child_manage_course_columns' );

function thim_child_manage_course_columns_content( $column ) {
	global $post;
	switch ( $column ) {
		case 'thim_price':
			$price      = get_post_meta( $post->ID, 'thim_course_price', true );
			$unit_price = get_post_meta( $post->ID, 'thim_course_unit_price', true );
			echo $price;
			if($price != '' && $unit_price != ''){
				echo '/';
			} else{
				echo ' ';
			}
			echo $unit_price;
	}
}

add_filter( 'manage_lp_course_posts_custom_column', 'thim_child_manage_course_columns_content' );

function thim_meta_course_new_art( $course_id ) {

	$price      = get_post_meta( $course_id, 'thim_course_price', true );
	$unit_price = get_post_meta( $course_id, 'thim_course_unit_price', true );
	$time               = get_post_meta( $course_id, 'thim_course_time', true );
	$day_of_week        = get_post_meta( $course_id, 'thim_course_day_of_week', true );
	?>

	<?php if($time != ''):?>
		<span class="course-meta-item course-time">
			<label><?php echo esc_html__('Time:','eduma-child');?></label>
			<?php echo esc_html($time);?>
		</span>
	<?php endif; ?>

	<?php if($day_of_week != ''):?>
		<span class="course-meta-item course-days-of-week">
			<label><?php echo esc_html__('Days of Week:','eduma-child');?></label>
			<?php echo esc_html($day_of_week);?>
		</span>
	<?php endif;?>

	<?php if($price != '' && $unit_price != ''):?>
		<span class="course-meta-item course-price">
			<span class="course-price-value"><?php echo esc_html($price);?></span>
			<span class="course-price-unit"><?php echo '/'. esc_html($unit_price);?></span>
		</span>
	<?php endif;?>
	<?php
}

function thim_related_courses() {
	$related_courses = thim_get_related_courses( 3 );

	if ( $related_courses ) {
		?>
		<div class="thim-ralated-course">
			<h3 class="related-title"><?php esc_html_e( 'You May Like', 'eduma-child' ); ?></h3>

			<div class="thim-course-grid">
				<?php foreach ( $related_courses as $course_item ) : ?>

					<article class="course-grid-3 lpr_course">
						<div class="course-item">
							<div class="course-thumbnail">
								<a href="<?php echo get_the_permalink( $course_item->ID ); ?>">
									<?php
									echo thim_get_feature_image( get_post_thumbnail_id( $course_item->ID ), 'full', 450, 450, get_the_title( $course_item->ID ) );
									?>
								</a>
								<?php do_action( 'thim_inner_thumbnail_course' ); ?>
								<?php echo '<a class="course-readmore" href="' . esc_url( get_the_permalink( $course_item->ID ) ) . '">' . esc_html__( 'Read More', 'eduma-child' ) . '</a>'; ?>
							</div>
							<div class="thim-course-content">

								<div class="course-author">
									<?php echo get_avatar( $course_item->post_author, 40 ); ?>
									<div class="author-contain">
										<div class="value">
											<?php echo get_the_author_meta( 'display_name', $course_item->post_author ); ?>
										</div>
									</div>
								</div>

								<h4 class="course-title">
									<a href="<?php echo esc_url( get_the_permalink( $course_item->ID ) ); ?>"> <?php echo get_the_title( $course_item->ID ); ?></a>
								</h4>

								<div class="course-meta">
									<?php thim_meta_course_new_art( $course_item->ID ); ?>
								</div>

							</div>
						</div>
					</article>
				<?php endforeach; ?>
			</div>
		</div>
		<?php
	}
}

function thim_course_info() {

	$course_id = get_the_ID();

	$duration           = get_post_meta( $course_id, 'thim_course_duration', true );
	$time               = get_post_meta( $course_id, 'thim_course_time', true );
	$day_of_week        = get_post_meta( $course_id, 'thim_course_day_of_week', true );
	$available_seats    = get_post_meta( $course_id, 'thim_course_available_seats', true );
	$skill_level        = get_post_meta( $course_id, 'thim_course_skill_levels', true );
	$thim_options       = get_theme_mods();

	$category = wp_get_post_terms( $course_id, 'course_category' );

	$cat_name = $category[0]->name;

	?>
	<div class="thim-course-info">
		<h3 class="title"><?php esc_html_e( 'Course Features', 'eduma-child' ); ?></h3>
		<ul>
			<li class="duration-feature">
				<i class="fa fa-clock-o"></i>
				<span class="label"><?php esc_html_e( 'Duration', 'eduma-child' ); ?></span>
				<span class="value"><?php echo esc_html( $duration ); ?></span>
			</li>
			<li class="time-feature">
				<i class="fa fa-bell-o"></i>
				<span class="label"><?php esc_html_e( 'Time', 'eduma-child' ); ?></span>
				<span class="value"><?php echo esc_html( $time ); ?></span>

			</li>
			<li class="day-of-week-feature">
				<i class="fa fa-calendar-o"></i>
				<span class="label"><?php esc_html_e( 'Day of week', 'eduma-child' ); ?></span>
				<span class="value"><?php echo esc_html( $day_of_week ); ?></span>

			</li>
			<li class="level-feature">
				<i class="fa fa-level-up"></i>
				<span class="label"><?php esc_html_e( 'Skill level', 'eduma-child' ); ?></span>
				<span class="value"><?php echo esc_html( $skill_level ); ?></span>
			</li>
			<li class="available-feature">
				<i class="fa fa-user-plus"></i>
				<span class="label"><?php esc_html_e( 'Available Seats', 'eduma-child' ); ?></span>
				<span class="value"><?php echo esc_html( $available_seats ); ?></span>
			</li>

		</ul>
		<?php
		if ( !empty( $thim_options['thim_learnpress_timetable_link'] ) ) {
			echo '<div class="text-center"><a class="thim-timetable-link" target="_blank" href="' . esc_url( $thim_options['thim_learnpress_timetable_link'] ) . '">' . esc_html( 'Courses Schedules', 'eduma' ) . '</a></div>';
		}
		?>
	</div>
	<?php
}

function thim_new_art_font_weight( $fonts ) {
	$body_font = get_theme_mod( 'thim_font_body');
	$body_font = $body_font['font-family'];
	$fonts[$body_font][] = '500';
	return $fonts;
}
add_filter( 'kirki/enqueue_google_fonts', 'thim_new_art_font_weight' );