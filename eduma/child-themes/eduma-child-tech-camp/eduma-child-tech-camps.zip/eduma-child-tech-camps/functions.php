<?php

function thim_child_enqueue_styles() {
	if ( is_multisite() ) {
		wp_enqueue_style( 'thim-child-style', get_stylesheet_uri(), array(), THIM_THEME_VERSION );
	} else {
		wp_enqueue_style( 'thim-parent-style', get_template_directory_uri() . '/style.css', array(), THIM_THEME_VERSION );
	}

	wp_enqueue_script( 'thim_child_script', get_stylesheet_directory_uri() . '/js/child_script.js', array( 'jquery' ), THIM_THEME_VERSION );
}
add_action( 'wp_enqueue_scripts', 'thim_child_enqueue_styles', 1 );

load_theme_textdomain( 'eduma-child', get_stylesheet_directory() . '/languages' );

add_filter( 'body_class', 'thim_tech_camps_custom_class' );
function thim_tech_camps_custom_class( $classes ) {
	$classes[] = 'thim-child-tech-camps';
	return $classes;
}

/**
 * Back to top
 */
if ( !function_exists( 'thim_back_to_top' ) ) {
    function thim_back_to_top() {
        if ( get_theme_mod( 'thim_show_to_top', false ) ) { ?>
            <a href="#" id="back-to-top">
                <i class="ion-ios-arrow-thin-up" aria-hidden="true"></i>
            </a>
            <?php
        }
    }
}
add_action( 'thim_end_wrapper_container', 'thim_back_to_top' );

function thim_tech_camps_font_weight( $fonts ) {
    /* add body font */
    $body_font = get_theme_mod( 'thim_font_body');
    $body_font = $body_font['font-family'];
    $fonts[$body_font][] = 'regular';
    $fonts[$body_font][] = '500';

    return $fonts;
}
add_filter( 'kirki/enqueue_google_fonts', 'thim_tech_camps_font_weight' );


/* custom size image shortcode Out team  */
function thim_custom_member_thumbnail_width($size_width) {
    $size_width = 260;
    return $size_width;
}
add_filter( 'thim_member_thumbnail_width', 'thim_custom_member_thumbnail_width' );

function thim_custom_member_thumbnail_height($size_height) {
    $size_height = 318;
    return $size_height;
}
add_filter('thim_member_thumbnail_height', 'thim_custom_member_thumbnail_height');