<?php

function thim_child_enqueue_styles() {
	if ( is_multisite() ) {
		wp_enqueue_style( 'thim-child-style', get_stylesheet_uri(), array(), THIM_THEME_VERSION );
	} else {
		wp_enqueue_style( 'thim-parent-style', get_template_directory_uri() . '/style.css', array(), THIM_THEME_VERSION );
	}

	wp_enqueue_script( 'thim_child_script', get_stylesheet_directory_uri() . '/js/child_script.js', array( 'jquery' ), THIM_THEME_VERSION );
}
add_action( 'wp_enqueue_scripts', 'thim_child_enqueue_styles', 1000 );

load_theme_textdomain( 'eduma-child', get_stylesheet_directory() . '/languages' );

add_filter( 'body_class', 'thim_tech_camps_custom_class' );
function thim_tech_camps_custom_class( $classes ) {
	$classes[] = 'thim-child-tech-camps';
	return $classes;
}

/**
 * Back to top
 */
if ( !function_exists( 'thim_back_to_top' ) ) {
    function thim_back_to_top() {
        if ( get_theme_mod( 'thim_show_to_top', false ) ) { ?>
            <a href="#" id="back-to-top">
                <i class="ion-ios-arrow-thin-up" aria-hidden="true"></i>
            </a>
            <?php
        }
    }
}
add_action( 'thim_end_wrapper_container', 'thim_back_to_top' );


/* custom size image shortcode Out team  */
function thim_custom_member_thumbnail_width($size_width) {
    if(is_front_page() || is_home() ) {
        $size_width = 260;
    } else{
        $size_width = 200;
    }
    return $size_width;
}
add_filter( 'thim_member_thumbnail_width', 'thim_custom_member_thumbnail_width' );

function thim_custom_member_thumbnail_height($size_height) {
    if(is_front_page() || is_home() ) {
        $size_height = 318;
    } else{
        $size_height = 200;
    }
    return $size_height;
}
add_filter('thim_member_thumbnail_height', 'thim_custom_member_thumbnail_height');

// Advanced changes to optimize demos
function thim_child_learnpress_feault_scripts($scripts) {
	if( is_front_page() ) {
		unset($scripts['lp-plugins-all']);
		unset($scripts['global']);
		unset($scripts['wp-utils']);
		unset($scripts['learnpress']);
		unset($scripts['checkout']);
		unset($scripts['course']);
		unset($scripts['quiz']);
		unset($scripts['profile-user']);
		unset($scripts['become-a-teacher']);
	}
	return $scripts;
}
add_filter('learn-press/frontend-default-scripts', 'thim_child_learnpress_feault_scripts');

function thim_child_buddypress_feault_scripts($scripts) {
	if( is_front_page() ) {
		unset($scripts['bp-confirm']);
		unset($scripts['bp-widget-members']);
		unset($scripts['bp-jquery-query']);
		unset($scripts['bp-jquery-cookie']);
		unset($scripts['bp-jquery-scroll-to']);
	}
	return $scripts;
}
add_filter('bp_core_register_common_scripts', 'thim_child_buddypress_feault_scripts');

function thim_child_slider_font_config($config) {
	$config = '';
	return $config;
}
add_filter('revslider_printCleanFontImport', 'thim_child_slider_font_config');