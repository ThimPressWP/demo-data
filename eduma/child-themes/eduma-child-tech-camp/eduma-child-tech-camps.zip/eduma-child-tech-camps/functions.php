<?php

function thim_child_enqueue_styles() {
	if ( is_multisite() ) {
		wp_enqueue_style( 'thim-child-style', get_stylesheet_uri(), array(), THIM_THEME_VERSION );
	} else {
		wp_enqueue_style( 'thim-parent-style', get_template_directory_uri() . '/style.css', array(), THIM_THEME_VERSION );
	}

	wp_enqueue_script( 'thim_child_script', get_stylesheet_directory_uri() . '/js/child_script.js', array( 'jquery' ), THIM_THEME_VERSION );
}
add_action( 'wp_enqueue_scripts', 'thim_child_enqueue_styles', 1 );

load_theme_textdomain( 'eduma-child', get_stylesheet_directory() . '/languages' );

add_filter( 'body_class', 'thim_tech_camps_custom_class' );
function thim_tech_camps_custom_class( $classes ) {
	$classes[] = 'thim-child-tech-camps';
	return $classes;
}

/* Replace courses meta */
function thim_add_course_meta( $meta_box ) {
    $fields             = array();
    $fields[]           = array(
        'name' => esc_html__( 'Duration Info', 'eduma-child' ),
        'id'   => 'thim_course_duration',
        'type' => 'text',
        'desc' => esc_html__( 'Display duration info', 'eduma-child' ),
        'std'  => esc_html__( '30 hours', 'eduma-child' )
    );
    $fields[]           = array(
        'name' => esc_html__( 'Time', 'eduma-child' ),
        'id'   => 'thim_course_time',
        'type' => 'text',
        'desc' => esc_html__( 'Show Time start and time end in course', 'eduma-child' ),
    );
    $fields[] = array(
        'name' => esc_html__( 'Day of Week', 'eduma-child' ),
        'id'   => 'thim_course_day_of_week',
        'type' => 'text',
        'desc' => esc_html__( 'Show Day of Week Course', 'eduma-child' ),
    );
    $fields[]           = array(
        'name' => esc_html__( 'Available Seats', 'eduma-child' ),
        'id'   => 'thim_course_available_seats',
        'type' => 'number',
        'desc' => esc_html__( 'Enter available seats', 'eduma-child' ),
        'std'  => esc_html__( '10', 'eduma-child' )
    );
    $fields[]           = array(
        'name' => esc_html__( 'Skill Levels', 'eduma-child' ),
        'id'   => 'thim_course_skill_levels',
        'type' => 'text',
        'desc' => esc_html__( 'Display skill levels', 'eduma-child' ),
        'std'  => esc_html__( 'All level', 'eduma-child' )
    );
    $fields[]           = array(
        'name' => esc_html__( 'Price', 'eduma-child' ),
        'id'   => 'thim_course_price',
        'type' => 'text',
        'desc' => esc_html__( 'Enter course price', 'eduma-child' ),
        'std'  => esc_html__( '$50', 'eduma-child' )
    );
    $fields[]           = array(
        'name' => esc_html__( 'Unit', 'eduma-child' ),
        'id'   => 'thim_course_unit_price',
        'type' => 'text',
        'desc' => esc_html__( 'Enter unit, for example, p/h, person/hour', 'eduma-child' ),
        'std'  => esc_html__( 'p/h', 'eduma-child' )
    );
    $fields[]           = array(
        'name' => esc_html__( 'Media Intro', 'eduma' ),
        'id'   => 'thim_course_media_intro',
        'type' => 'textarea',
        'desc' => esc_html__( 'Enter media intro', 'eduma' ),
    );
    $meta_box['fields'] = $fields;
    return $meta_box;
}

//Remove tab assessment & payment from LP 2.1.3
add_filter( 'learn_press_lp_course_tabs', 'thim_remove_tabs_course' );
function thim_remove_tabs_course( $tabs ) {
    if ( !empty( $tabs ) ) {
        foreach ( $tabs as $tab_id => $tab ) {
            if ( !empty( $tab->meta_box ) && is_array( $tab->meta_box ) ) {
                $id = $tab->meta_box['id'];
                if ( !empty( $id ) ) {
                    if ( in_array( $id, array( 'course_payment', 'course_assessment' ) ) ) {
                        unset( $tabs[$tab_id] );
                    }
                }
            }
        }
    }
    return $tabs;
}
function thim_child_manage_course_columns( $columns ) {
    unset( $columns['price'] );
    $keys   = array_keys( $columns );
    $values = array_values( $columns );
    $pos    = array_search( 'sections', $keys );
    if ( $pos !== false ) {
        array_splice( $keys, $pos + 1, 0, array( 'thim_price' ) );
        array_splice( $values, $pos + 1, 0, __( 'Price', 'eduma' ) );
        $columns = array_combine( $keys, $values );
    } else {
        $columns['thim_price'] = __( 'Price', 'eduma' );
    }
    return $columns;
}
add_filter( 'manage_lp_course_posts_columns', 'thim_child_manage_course_columns' );
function thim_child_manage_course_columns_content( $column ) {
    global $post;
    switch ( $column ) {
        case 'thim_price':
            $price      = get_post_meta( $post->ID, 'thim_course_price', true );
            $unit_price = get_post_meta( $post->ID, 'thim_course_unit_price', true );
            echo $price;
            if($price != '' && $unit_price != ''){
                echo '/';
            } else{
                echo ' ';
            }
            echo $unit_price;
    }
}
add_filter( 'manage_lp_course_posts_custom_column', 'thim_child_manage_course_columns_content' );


/**
 * Back to top
 */
if ( !function_exists( 'thim_back_to_top' ) ) {
    function thim_back_to_top() {
        if ( get_theme_mod( 'thim_show_to_top', false ) ) { ?>
            <a href="#" id="back-to-top">
                <i class="ion-ios-arrow-thin-up" aria-hidden="true"></i>
            </a>
            <?php
        }
    }
}
add_action( 'thim_end_wrapper_container', 'thim_back_to_top' );

function thim_tech_camps_font_weight( $fonts ) {
    /* add body font */
    $body_font = get_theme_mod( 'thim_font_body');
    $body_font = $body_font['font-family'];
    $fonts[$body_font][] = 'regular';
    $fonts[$body_font][] = '500';

    return $fonts;
}
add_filter( 'kirki/enqueue_google_fonts', 'thim_tech_camps_font_weight' );


/* form register in single course */
function thim_register_course() {
    if(is_singular('lp_course')){
        ?>
            <div id="contact-form-registration" class="">
                <?php
                $thim_options = get_theme_mods();
                $contact_form = $thim_options['thim_learnpress_shortcode_contact'];
                $contact = str_replace('&quot;','"',$contact_form);

                if ( ! empty( $contact_form ) ) {
                    echo do_shortcode( $contact );
                }

                ?>
            </div>
        <?php
    }
}
add_action('thim_end_wrapper_container','thim_register_course');

/* custom size image shortcode Out team  */
function thim_custom_member_thumbnail_width($size_width) {
    $size_width = 260;
    return $size_width;
}
add_filter( 'thim_member_thumbnail_width', 'thim_custom_member_thumbnail_width' );

function thim_custom_member_thumbnail_height($size_height) {
    $size_height = 318;
    return $size_height;
}
add_filter('thim_member_thumbnail_height', 'thim_custom_member_thumbnail_height');