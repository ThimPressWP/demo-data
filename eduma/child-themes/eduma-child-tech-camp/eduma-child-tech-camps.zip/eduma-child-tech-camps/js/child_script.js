(function ($) {
	"use strict";
	var register_button = function(){
		$('#contact-form-registration').find('.wpcf7').append('<a href="javascript:void(0)" class="close-button"><i class="ion-close-round"></i></a>');
		var $close_button = $('#contact-form-registration .wpcf7').find('.close-button');
		var $thim_enroll_course_button = $('.thim-enroll-kid-art').find('.thim-enroll-course-button');

		$($thim_enroll_course_button).on('click',function () {
			$('#contact-form-registration').addClass('active');
        });

		$($close_button).on('click',function () {
            $('#contact-form-registration').removeClass('active');
        })
	}

    $(window).load(function () {
        register_button();
	});

})(jQuery);