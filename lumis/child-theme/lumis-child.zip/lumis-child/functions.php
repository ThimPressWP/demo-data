<?php

function theme_lumis_child_enqueue_styles() {
	wp_enqueue_style('thim-parent-style', get_template_directory_uri() . '/style.css', array(), THIM_THEME_VERSION);
}

add_action( 'wp_enqueue_scripts', 'theme_lumis_child_enqueue_styles', 100 );