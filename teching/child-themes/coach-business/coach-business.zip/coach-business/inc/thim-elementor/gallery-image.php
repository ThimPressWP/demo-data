<?php
add_action( 'elementor/element/gallery-image/section_content/after_section_start', 'thim_child_gallery_image_custom_field', 10, 2 );

function thim_child_gallery_image_custom_field( $element, $args ) {
	$element->add_control( 'layout',
		[
			'label' => esc_html__( 'Layout', 'coach-business' ),
			'type' => \Elementor\Controls_Manager::SELECT,
			'default' => 'slider',
			'options' => array(
				'default' => esc_html__('Default','coach-business'),
				'slider' => esc_html__('Slider','coach-business'),
			)
		]
	);
}