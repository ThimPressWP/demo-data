<?php
/**
 * Template for displaying default template gallery image element.
 *
 * This template can be overridden by copying it to yourtheme/thim-elementor/gallery-image/slider.php.
 *
 * @author      ThimPress
 * @package     Thimpress/Templates
 * @version     1.0.0
 * @author      Thimpress, leehld
 */


/**
 * Prevent loading this file directly
 */
defined( 'ABSPATH' ) || exit;
$gallery_item   = isset($settings['gallery_item']) ? $settings['gallery_item'] : '';
$image_size     = isset($settings['image_size']) ? $settings['image_size'] : 'thumbnail';
?>
<div class="wrap-element">
	<?php if($gallery_item): ?>
	<div class="js-call-slick-col dot-has-process" data-pagination="" data-speedslide="900" data-numofslide="1" data-numofscroll="1" data-loopslide="1" data-autoscroll="1" data-speedauto="5000" data-respon="[1, 1], [1, 1], [1, 1], [1, 1], [1, 1]" data-customdot="1">

		<div class="slide-slick">
			<?php
			$i=0;
			foreach ($gallery_item as $gallery_items):
				$i++;
				$full = wp_get_attachment_image_src( $gallery_items['id'], 'full' );
				$full = $full[0];
				?>
				<div class="item-slick" data-thumb="<?php echo $i; ?>">
					<a href="<?php echo esc_attr($full); ?>" class="gallery-item js-show-gallery">
						<?php echo wp_get_attachment_image( $gallery_items['id'], $image_size, "", array( "class" => "img-responsive" ) );  ?>
					</a>
				</div>
			<?php
			endforeach;
			?>
		</div>

		<div class="wrap-arrow-slick">
			<div class="arow-slick prev-slick">
				<i class="ion ion-ios-arrow-thin-left"></i>
			</div>

			<div class="arow-slick next-slick">
				<i class="ion ion-ios-arrow-thin-right"></i>
			</div>
		</div>

		<div class="wrap-dot-slick"></div>
	</div>
	<?php endif; ?>
</div>
