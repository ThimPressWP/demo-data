<?php
/**
 * Template for displaying default template Testimonials element.
 *
 * This template can be overridden by copying it to yourtheme/thim-elementor/testimonials/testimonials.php.
 *
 * @author      ThimPress
 * @package     Thimpress/Templates
 * @version     1.0.0
 * @author      Thimpress, leehld
 */

/**
 * Prevent loading this file directly
 */
defined( 'ABSPATH' ) || exit;
$testimonials   = isset($settings['testimonials']) ? $settings['testimonials'] : '';
$item           = isset($settings['item']) ? $settings['item'] : 1;
$item_tablet    = isset($settings['item_tablet']) ? $settings['item_tablet'] : 1;
$item_mobile    = isset($settings['item_mobile']) ? $settings['item_mobile'] : 1;
$navigation     = isset($settings['navigation']) ?  $settings['navigation'] : 'none';
?>

<div class="slide-testimonials js-call-slick-col" data-numofslide="<?php echo esc_attr($item); ?>" data-numofscroll="1" data-loopslide="1" data-autoscroll="1"
     data-speedauto="600" data-respon="[<?php echo esc_attr($item); ?>, 1], [<?php echo esc_attr($item); ?>, 1], [<?php echo esc_attr($item_tablet); ?>, 1], [<?php echo esc_attr($item_mobile); ?>, 1], [<?php echo esc_attr($item_mobile); ?>, 1]">
    <div class="slide-slick">
        <?php foreach ($testimonials as $index => $item) {
            $repeater_setting_key_description = 'testimonials.'. $index . '.description';
            $repeater_setting_key_name = 'testimonials.'. $index . '.name';
            $repeater_setting_key_info = 'testimonials.'. $index . '.info';
            ?>
            <div class="testimonial-item">
                <div class="text">
                    <div <?php echo $attribute[$repeater_setting_key_description]; ?>><?php echo esc_html( $item['description'] ) ?></div>

                    <div class="info">
	                    <div class="avatar">
		                    <?php
		                    $thumbnail_id = (int) $item['avatar']['id'];
		                    $size         = apply_filters( 'thim-elementor/testimonial/default/image-size', '60x60' );
		                    thim_elementor_get_attachment_image( $thumbnail_id, $size );
		                    ?>
	                    </div>
	                    <div class="info-name">
		                    <?php if($item['name']): ?>
			                    <h4 <?php echo $attribute[$repeater_setting_key_name]; ?>><?php echo esc_html( $item['name'] ); ?></h4>
		                    <?php endif; ?>

		                    <?php if($item['info']): ?>
			                    <span <?php echo $attribute[$repeater_setting_key_info]; ?>><?php echo esc_html( $item['info'] ); ?></span>
		                    <?php endif; ?>
	                    </div>
                    </div>
                </div>
            </div>
        <?php } ?>
    </div>

    <?php if($navigation === 'both' || $navigation === 'arrows' ):?>
        <div class="wrap-arrow-slick">
            <div class="arow-slick prev-slick">
                <i class="fa fa-long-arrow-left" aria-hidden="true"></i>
            </div>

            <div class="arow-slick next-slick">
                <i class="fa fa-long-arrow-right" aria-hidden="true"></i>
            </div>
        </div>
    <?php endif; ?>

    <?php if($navigation === 'both' || $navigation === 'dots' ):?>
        <div class="wrap-dot-slick"></div>
    <?php endif; ?>

</div>


