<?php
add_action( 'elementor/element/heading/section_title/before_section_end', 'thim_heading_custom_field', 10, 2 );

function thim_heading_custom_field( $element, $args ) {
	$element->add_control( 'style',
		[
			'label' => esc_html__( 'Style', 'coach-health' ),
			'type' => \Elementor\Controls_Manager::SELECT,
			'default' => 'default',
			'options' => array(
				'default' => esc_html__('Title before Subtitle','coach-health'),
				'style-1' => esc_html__('Title after Subtitle','coach-health'),
			)
		]
	);
}