<?php

define( 'THIM_CHILD_DIR', trailingslashit( get_stylesheet_directory() ) );
define( 'THIM_CHILD_URI', trailingslashit( get_stylesheet_directory_uri() ) );
define( 'THIM_CHILD_VERSION', '1.0.0' );

function thim_child_enqueue_styles() {
	if ( is_multisite() ) {
		wp_enqueue_style( 'thim-child-style', get_stylesheet_uri(), array(), THIM_CHILD_VERSION );
	} else {
		wp_enqueue_style( 'thim-parent-style', get_template_directory_uri() . '/style.css', array(), THIM_CHILD_VERSION );
	}
}

add_action( 'wp_enqueue_scripts', 'thim_child_enqueue_styles', 1000 );

load_theme_textdomain( 'coach-mentor', get_stylesheet_directory() . '/languages' );

add_filter( 'body_class', 'thim_child_custom_class' );
function thim_child_custom_class( $classes ) {
	$classes[] = 'thim-coach-mentor';
	return $classes;
}

include_once( ABSPATH . 'wp-admin/includes/plugin.php' );

if ( is_plugin_active( 'thim-elementor/thim-elementor.php' ) ) {
	require_once(THIM_CHILD_DIR . 'inc/thim-elementor-functions.php');
}