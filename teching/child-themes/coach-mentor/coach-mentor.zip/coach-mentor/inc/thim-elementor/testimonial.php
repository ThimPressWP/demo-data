<?php
add_action( 'elementor/element/testimonials/section_content/before_section_end', 'thim_testimonials_update_field', 10, 2 );

function thim_testimonials_update_field( $element, $args ) {

	$testimonials = array(
		'label'   => esc_html__( 'Testimonials', 'coach-mentor' ),
		'type'    => \Elementor\Controls_Manager::REPEATER,
		'fields'  => [
			[
				'name'       => 'name',
				'label'      => esc_html__('Name','coach-mentor'),
				'type'       => \Elementor\Controls_Manager::TEXT,
				'placeholder'=> esc_html__('Author Name','coach-mentor'),
				'default'    => esc_html__('Name','coach-mentor'),
			],
			[
				'name'      => 'info',
				'label'     => esc_html__('Info','coach-mentor'),
				'type'      => \Elementor\Controls_Manager::TEXT,
			],
			[
				'name'       => 'title',
				'label'      => esc_html__('Title','coach-mentor'),
				'type'       => \Elementor\Controls_Manager::TEXT,
				'placeholder'=> esc_html__('Title','coach-mentor'),
				'default'    => esc_html__('Title','coach-mentor'),
			],
			[
				'name'       => 'description',
				'label'      => esc_html__('Content','coach-mentor'),
				'type'       => \Elementor\Controls_Manager::TEXTAREA,
				'placeholder'=> __('Content Description','coach-mentor'),
			],
			[
				'name'    => 'avatar',
				'label'   => esc_html__( 'Avatar', 'coach-mentor' ),
				'type'    => \Elementor\Controls_Manager::MEDIA,
				'dynamic' => [
					'active' => true,
				],
				'default' => [
					'url' => '#',
				],
			],
			[
				'name'  => 'link',
				'label' => esc_html__( 'Link', 'coach-mentor' ),
				'type'  => \Elementor\Controls_Manager::URL,
				'dynamic'    => [
					'active' => true,
				],
				'placeholder' => esc_html__( 'https://your-link.com', 'coach-mentor' ),
				'default' => [
					'url' => '#',
				],
			],
		]
	);
	$element->update_control( 'testimonials', $testimonials );
}