<?php
/**
 * Template for displaying default template Learnpress List Courses element layout default.
 *
 * This template can be overridden by copying it to yourtheme/thim-elementor/courses/default.php
 *
 * @author      ThimPress
 * @package     ThimElementor/Templates
 * @version     1.0.0
 * @author      Thimpress, leehld
 */

/**
 * Prevent loading this file directly
 */
defined( 'ABSPATH' ) || exit;

$title  = isset($settings['title']) ? $settings['title'] : '';
$view_all_courses  = isset($settings['view_all_courses']) ? $settings['view_all_courses'] : '';
?>
<div <?php echo $attribute['wrapper'] ?>>
    <?php if($title): ?>
        <h3 <?php echo $attribute['title'] ?>> <?php echo esc_html($title); ?> </h3>
    <?php endif; ?>
    <div class="row">
        <?php while ( $courses->have_posts() ) : $courses->the_post(); ?>
            <?php
	        $course = learn_press_get_course( get_the_ID() );
	        if ( is_plugin_active( 'learnpress-course-review/learnpress-course-review.php' ) ) {
		        $course_rate = learn_press_get_course_rate( get_the_ID() );
	        }
	        $number_students = intval($course->count_students());
	        $num = $number_students/1000 - (($number_students%1000)/1000);
	        $number_students = $num > 0 ? $num . 'K' : $number_students;
            ?>
            <div class="col-md-4">
	            <div class="item-course">
		            <div class="image-course">
			            <a href="<?php the_permalink(); ?>">
				            <?php
				            $size =  apply_filters('thim-elementor/courses/default/image-size','450x300');
				            thim_elementor_get_attachment_image(get_post_thumbnail_id(get_the_ID()), $size);
				            ?>
			            </a>

			            <div class="price-course">
				            <?php echo esc_html( $course->get_price_html() ); ?>
				            <?php if ( $course->has_sale_price() ) { ?>
					            <span class="old-price"> <?php echo esc_html( $course->get_origin_price_html() ); ?></span>
				            <?php } ?>
			            </div>
		            </div>

		            <div class="text-course">
			            <h4 class="title-course">
				            <a href="<?php the_permalink(); ?>">
					            <?php the_title(); ?>
				            </a>
			            </h4>

			            <div class="description-course">
				            <?php echo wp_trim_words( get_the_excerpt(), 13,'' ); ?>
			            </div>

			            <div class="foot-item">
				            <div class="author-course">
                                <span class="ava-author">
                                    <?php echo $course->get_instructor()->get_profile_picture( '', 39 ); ?>
                                </span>

					            <span class="name-author">
						            <?php echo $course->get_instructor_html(); ?>
					            </span>
				            </div>

				            <div class="info-course">
                                <span class="item-info">
                                    <i class="ion ion-android-person"></i>
                                    <?php echo esc_html($number_students);?>
                                </span>

					            <?php
					            if ( is_plugin_active( 'learnpress-course-review/learnpress-course-review.php' ) ) {
						            ?>
						            <span class="item-info">
							            <i class="ion ion-android-star"></i>
							            <?php echo intval( $course_rate );?>
					                </span>
					                <?php
					            }
					            ?>
				            </div>
			            </div>
		            </div>
	            </div>
            </div>
        <?php endwhile; ?>
    </div>

    <?php
    if(!empty($view_all_courses)) {
        ?>
	    <div class="view-all">
		    <a href="<?php echo get_post_type_archive_link('lp_course') ?>"><?php echo esc_html($view_all_courses); ?></a>
	    </div>
        <?php
    }
    ?>
</div>

