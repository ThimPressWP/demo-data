<?php
/**
 * Template for displaying default template Testimonials element.
 *
 * This template can be overridden by copying it to yourtheme/thim-elementor/testimonials/testimonials.php.
 *
 * @author      ThimPress
 * @package     Thimpress/Templates
 * @version     1.0.0
 * @author      Thimpress, leehld
 */

/**
 * Prevent loading this file directly
 */
defined( 'ABSPATH' ) || exit;
$testimonials   = isset($settings['testimonials']) ? $settings['testimonials'] : '';
$item           = isset($settings['item']) ? $settings['item'] : 1;
$item_tablet    = isset($settings['item_tablet']) ? $settings['item_tablet'] : 1;
$item_mobile    = isset($settings['item_mobile']) ? $settings['item_mobile'] : 1;
$navigation     = isset($settings['navigation']) ?  $settings['navigation'] : 'none';
$rtl_att = (get_theme_mod( 'feature_rtl_support', false ) || is_rtl()) ? ' data-rtl="1" dir="rtl"' : '';
?>

<div class="row">
	<div class="col-md-6">
		<div class="slide-image js-call-slick-col"<?php echo $rtl_att;?> data-numofslide="1" data-numofscroll="1" data-loopslide="1" data-autoscroll="<?php echo $auto_slide;?>" data-speedauto="<?php echo $speed_auto;?>" data-respon="[1, 1], [1, 1], [1, 1], [1, 1], [1, 1]" data-navfor="#text-testimonial-01" data-modecenter="1" data-paddingcenter="0px" data-speedslide="1000">
			<div class="wrap-arrow-slick">
				<div class="arow-slick prev-slick"></div>
			</div>
			<div id="image-testimonial-01" class="slide-slick">
				<?php
				foreach ($testimonials as $index => $item) { ?>
					<div class="item-slick">
						<div class="item-image">
							<?php
							$thumbnail_id = (int) $item['avatar']['id'];
							$size         = apply_filters( 'thim-elementor/testimonial/default/image-size', '380x510' );
							thim_elementor_get_attachment_image( $thumbnail_id, $size );
							?>
						</div>
					</div>
				<?php } ?>
			</div>
		</div>
	</div>

	<div class="col-md-6">
		<div class="slide-text js-call-slick-col"<?php echo $rtl_att;?> data-numofslide="1" data-numofscroll="1" data-loopslide="1" data-autoscroll="0" data-speedauto="6000" data-respon="[1, 1], [1, 1], [1, 1], [1, 1], [1, 1]" data-fade="1" data-navfor="#image-testimonial-01" data-speedslide="1000">
			<div id="text-testimonial-01" class="slide-slick">
				<?php
				foreach ($testimonials as $index => $item) {
					$repeater_setting_key_description = 'testimonials.'. $index . '.description';
					$repeater_setting_key_name = 'testimonials.'. $index . '.name';
					$repeater_setting_key_info = 'testimonials.'. $index . '.info';
					?>
					<div class="item-slick">
						<div class="item-text">

							<?php
							if(isset($item['title'])):
								?>
								<h3 class="testimonial-title"><?php echo esc_html( $item['title'] ) ?></h3>
							<?php endif; ?>

							<?php
							if(isset($item['description'])):
								?>
								<div <?php echo $attribute[$repeater_setting_key_description]; ?>>
									<?php echo esc_html( $item['description'] ) ?>
								</div>
							<?php endif; ?>
							<div class="author-testimonial">
								<?php if($item['name']): ?>
									<h4 <?php echo $attribute[$repeater_setting_key_name]; ?>><?php echo esc_html( $item['name'] ); ?></h4>
								<?php endif; ?>

								<?php if($item['info']): ?>
									<span <?php echo $attribute[$repeater_setting_key_info]; ?>><?php echo esc_html( $item['info'] ); ?></span>
								<?php endif; ?>
							</div>
						</div>
					</div>
				<?php } ?>
			</div>

			<div class="wrap-arrow-slick">
				<div class="arow-slick prev-slick">
					<i class="ion ion-ios-arrow-thin-left"></i>
				</div>
				<div class="arow-slick next-slick">
					<i class="ion ion-ios-arrow-thin-right"></i>
				</div>
			</div>
		</div>
	</div>
</div>


