<?php

// include config
$config_path = THIM_CHILD_DIR . 'inc/thim-elementor/';

require_once $config_path . 'heading.php';
require_once $config_path . 'gallery-image.php';