<?php
add_action( 'elementor/element/gallery-image/section_content/before_section_end', 'thim_gallery_image_custom_field', 10, 2 );
function thim_gallery_image_custom_field( $element, $args ) {
	$element->remove_control('gallery_item');
	$element->remove_control('image_size');

	$element->add_control(
		'title',
		[
			'label'   => esc_html__( 'Title', 'coach-yoga' ),
			'type'    => \Elementor\Controls_Manager::TEXTAREA,
			'dynamic' => [
				'active' => true,
			],
			'placeholder' => esc_html__( 'Enter your title', 'coach-yoga' ),
			'default'     => esc_html__( 'Add Your Title Here', 'coach-yoga' ),
		]
	);

	$element->add_control(
		'subtitle',
		[
			'label'   => esc_html__( 'Subtitle', 'coach-yoga' ),
			'type'    => \Elementor\Controls_Manager::TEXTAREA,
			'dynamic' => [
				'active' => true,
			],
			'placeholder' => esc_html__( 'Enter your subtitle', 'coach-yoga' ),
			'default'     => esc_html__( 'Add Your Subtitle Here', 'coach-yoga' ),
		]
	);

	$element->add_control(
		'description',
		[
			'label'   => esc_html__( 'Description', 'coach-yoga' ),
			'type'    => \Elementor\Controls_Manager::TEXTAREA,
			'dynamic' => [
				'active'  => true,
			],
			'placeholder' => esc_html__( 'Enter your description', 'coach-yoga' ),
			'default'     => esc_html__( 'Add Your Description Here', 'coach-yoga' ),
		]
	);

	$element->add_control(
		'button_text',
		[
			'label' => esc_html__( 'Button Text', 'coach-yoga' ),
			'type' => \Elementor\Controls_Manager::TEXT,
			'dynamic' => [
				'active' => true,
			],
			'default' => esc_html__( 'Join Now', 'coach-yoga' ),
			'placeholder' => esc_html__( 'Button Text', 'coach-yoga' ),
		]
	);

	$element->add_control(
		'button_link',
		[
			'label' => esc_html__( 'Button Link', 'coach-yoga' ),
			'type' => \Elementor\Controls_Manager::URL,
			'dynamic' => [
				'active' => true,
			],
			'placeholder' => esc_html__( 'https://', 'coach-yoga' ),
		]
	);

	$element->add_control(
		'images',
		[
			'label'   => esc_html__( 'Images', 'coach-yoga' ),
			'type'    => \Elementor\Controls_Manager::REPEATER,
			'fields'  => [
				[
					'name' => 'image',
					'label' => __( 'Choose Image', 'elementor' ),
					'type' => \Elementor\Controls_Manager::MEDIA,
					'dynamic' => [
						'active' => true,
					],
					'default' => ''
				],
				[
					'name' => 'size',
					'label' => esc_html__( 'Size', 'coach-yoga' ),
					'type' => \Elementor\Controls_Manager::SELECT,
					'default' => '1x1',
					'options' => array(
						'1x1' => esc_html__('1x1','coach-yoga'),
						'2x2' => esc_html__('2x2','coach-yoga'),
						'3x2' => esc_html__('3x2','coach-yoga'),
					)
				],
				[
					'name'       => 'image_title',
					'label'      => esc_html__('Title','coach-yoga'),
					'type'       => \Elementor\Controls_Manager::TEXT,
					'placeholder'=> esc_html__('Image Title','coach-yoga'),
					'default'    => esc_html__('Image Title','coach-yoga'),
				],
				[
					'name'       => 'image_subtitle',
					'label'      => esc_html__('Sub Title','coach-yoga'),
					'type'       => \Elementor\Controls_Manager::TEXT,
					'placeholder'=> esc_html__('Image Sub Title','coach-yoga'),
					'default'    => esc_html__('Image Sub Title','coach-yoga'),
				],
			]
		]
	);

}

//add_action( 'elementor/widget/before_render_content', 'thim_image_render' );
//function thim_image_render( $button ) {
//	//Check if we are on a button
//	if( 'image' === $button->get_name() ) {
//		// Get the settings
//		$settings = $button->get_settings();
//
//		// Adding our type as a class to the button
//		if( $settings['shape_position'] ) {
//			$button->add_render_attribute( 'wrapper', 'class', 'shape-'. $settings['shape_position'], true );
//		}
//	}
//}