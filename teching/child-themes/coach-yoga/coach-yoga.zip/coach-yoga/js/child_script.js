(function ($) {
	"use strict";

	var bp_grid_isotope = function() {
		if ( $().isotope ) {
			$('.grid-isotope').isotope({
				// set itemSelector so .grid-sizer is not used in layout
				itemSelector: '.grid-item',
				percentPosition: true,
				masonry: {
					// use element for option
					columnWidth: '.grid-sizer'
				},
			});
		}
	};

	$(window).on('elementor/frontend/init', function() {
		elementorFrontend.hooks.addAction('frontend/element_ready/gallery-image.default',
			bp_grid_isotope);
	});
})(jQuery);