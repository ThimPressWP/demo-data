<?php
/**
 * Template for displaying default template Learnpress List Courses element layout default.
 *
 * This template can be overridden by copying it to yourtheme/thim-elementor/courses/default.php
 *
 * @author      ThimPress
 * @package     ThimElementor/Templates
 * @version     1.0.0
 * @author      Thimpress, leehld
 */

/**
 * Prevent loading this file directly
 */
defined( 'ABSPATH' ) || exit;

$title  = isset($settings['title']) ? $settings['title'] : '';
$view_all_courses  = isset($settings['view_all_courses']) ? $settings['view_all_courses'] : '';
$item        = isset($settings['item']) ? $settings['item'] : 4;
$item_tablet = isset($settings['item_tablet']) ? $settings['item_tablet'] : 2;
$item_mobile = isset($settings['item_mobile']) ? $settings['item_mobile'] : 1;
$navigation  = isset($settings['navigation']) ?  $settings['navigation'] : 'none';
?>
<div <?php echo $attribute['wrapper']; ?>>
    <?php if($title): ?>
        <h3 <?php echo $attribute['title']; ?>> <?php echo esc_html($title); ?> </h3>
    <?php endif; ?>

	<div class="js-call-slick-col show-dot-number" data-pagination="" data-numofslide="<?php echo esc_attr($item); ?>" data-numofscroll="1" data-loopslide="0" data-autoscroll="0" data-speedauto="6000"
	     data-respon="[<?php echo esc_attr($item) ?>,1],[<?php echo esc_attr($item) ?>,1],[<?php echo esc_attr($item_tablet) ?>,1],[<?php echo esc_attr($item_mobile) ?>,1],[<?php echo esc_attr($item_mobile) ?>,1]">

		<div class="slide-slick">
			<?php
			while ( $courses->have_posts() ) : $courses->the_post();
				$course = learn_press_get_course( get_the_ID() );
				$course_rate = learn_press_get_course_rate( get_the_ID() );
				$number_students = intval($course->count_students());
				$num = $number_students/1000 - (($number_students%1000)/1000);
				$number_students = $num > 0 ? $num . 'K' : $number_students;
				?>
				<div class="item-slick">
					<div class="item-course">
						<div class="image-course">
							<a href="<?php the_permalink(); ?>" class="image-course">
								<?php
								$size =  apply_filters('thim-elementor/courses/slider/image-size','500x327');
								thim_elementor_get_attachment_image(get_post_thumbnail_id(get_the_ID()), $size);
								?>
							</a>

							<div class="price-course">
								<?php echo esc_html( $course->get_price_html() ); ?>
								<?php if ( $course->has_sale_price() ) { ?>
									<span class="old-price"> <?php echo esc_html( $course->get_origin_price_html() ); ?></span>
								<?php } ?>
							</div>
						</div>

						<div class="text-course">
							<h4 class="title-course">
								<a href="<?php the_permalink(); ?>">
									<?php echo get_the_title(); ?>
								</a>
							</h4>

							<div class="description-course">
								<?php echo wp_trim_words( get_the_excerpt(), 13,'' ); ?>
							</div>

							<div class="foot-item">
								<div class="author-course">
									<a href="#" class="ava-author">
										<?php echo $course->get_instructor()->get_profile_picture( '', 39 ); ?>
									</a>

									<span class="name-author">
                                        <?php echo $course->get_instructor_html(); ?>
                                    </span>
								</div>

								<div class="info-course">
                                    <span class="item-info">
                                        <i class="ion ion-android-person"></i> <?php echo esc_html($number_students);?>
                                    </span>

									<span class="item-info">
                                        <i class="ion ion-android-star"></i> <?php echo intval( $course_rate );?>
                                    </span>
								</div>
							</div>
						</div>
					</div>
				</div>
			<?php
			endwhile;
			wp_reset_postdata();
			?>
		</div>

		<?php if($navigation === 'both' || $navigation === 'arrows' ):?>
			<div class="wrap-arrow-slick">
				<div class="arow-slick prev-slick">
					<i class="ion ion-ios-arrow-thin-left"></i>
				</div>
				<?php endif;?>

				<?php if($navigation === 'both' || $navigation === 'dots' ):?>
					<div class="wrap-dot-slick"></div>
				<?php endif; ?>

				<?php if($navigation === 'both' || $navigation === 'arrows' ):?>
				<div class="arow-slick next-slick">
					<i class="ion ion-ios-arrow-thin-right"></i>
				</div>
			</div>
		<?php endif; ?>
	</div>

    <?php
    if(!empty($view_all_courses)) {
        ?>
        <a href="<?php echo get_post_type_archive_link('lp_course') ?>"><?php echo esc_html($view_all_courses); ?></a>
        <?php
    }
    ?>
</div>

