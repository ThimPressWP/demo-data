<?php
/**
 * Template for displaying default template gallery image element.
 *
 * This template can be overridden by copying it to yourtheme/thim-elementor/gallery-image/default.php.
 *
 * @author      ThimPress
 * @package     Thimpress/Templates
 * @version     1.0.0
 * @author      Thimpress, leehld
 */


/**
 * Prevent loading this file directly
 */
defined( 'ABSPATH' ) || exit;
$title   = isset($settings['title']) ? $settings['title'] : '';
$subtitle   = isset($settings['subtitle']) ? $settings['subtitle'] : '';
$description   = isset($settings['description']) ? $settings['description'] : '';
$button_text   = isset($settings['button_text']) ? $settings['button_text'] : '';
$button_link   = isset($settings['button_link']) ? $settings['button_link'] : '';
$images     = isset($settings['images']) ? $settings['images'] : '';

$sizes = apply_filters( 'thim-elementor/gallery-image/default/image-size', array(
	'1x1' => '360x320',
	'2x2' => '360x680',
	'3x2' => '760x320'
) );
?>

<div class="wrap-element grid-isotope grid gallery-popup">
	<div class="grid-sizer"></div>

	<?php
	$ratio = $images[0]['size'];
	$image_title = $images[0]['image_title'];
	$image_subtitle = $images[0]['image_subtitle'];
	$size  = apply_filters( 'thim-elementor/gallery-image/default/image-size', '360x320' );
	$url_image = wp_get_attachment_image_src( $images[0]['image']['id'], 'full' );
	if ( array_key_exists( $ratio, $sizes ) ) {
		$size = $sizes[ $ratio ];
	}
	if($ratio === '3x2'){
		$class = "size-2x";
	}else{
		$class = "";
	}
	?>

	<div class="grid-item <?php echo esc_attr($class); ?>">
		<div class="item-image">
			<a href="<?php echo esc_url($images[0]['image']['url']); ?>" class="wrap-image js-show-gallery">
				<?php
				thim_elementor_get_attachment_image( $images[0]['image']['id'], $size );
				?>
			</a>

			<div class="wrap-text">
				<?php
				if(!empty($image_title)):
					?>
					<h4 class="title-item">
						<?php echo esc_html($image_title); ?>
					</h4>
				<?php
				endif;
				?>

				<?php
				if(!empty($image_subtitle)):
					?>
					<div class="description-item">
						<?php echo esc_html($image_subtitle); ?>
					</div>
				<?php
				endif;
				?>
			</div>
		</div>
	</div>

	<?php

	?>
	<div class="grid-item">
		<div class="item-text">
			<div class="content-item">
				<?php
				if(!empty($subtitle)):
					?>
					<div class="description-item">
						<?php echo esc_html($subtitle); ?>
					</div>
				<?php
				endif;
				?>

				<?php
				if(!empty($title)):
					?>
					<h4 class="title-item">
						<?php echo esc_html($title); ?>
					</h4>
				<?php
				endif;
				?>

				<?php
				if(!empty($description)):
					?>
					<div class="description-item">
						<?php echo esc_html($description); ?>
					</div>
				<?php
				endif;
				?>

				<?php
				if ( $button_text != '' && $button_link != '') {
					?>
					<a href="<?php echo esc_url($button_link['url']); ?>" class="button-item">
						<?php echo esc_html($button_text); ?>
					</a>
				<?php } ?>
			</div>
		</div>
	</div>

	<?php
	global $class;
	$i = 1;
	foreach ($images as $img){
		$i++;
		$ratio = $img['size'];
		$img_title = $img['image_title'];
		$img_subtitle = $img['image_subtitle'];
		$size  = apply_filters( 'thim-elementor/gallery-image/default/image-size', '360x320' );
		$url_image = wp_get_attachment_image_src( $img['image']['id'], 'full' );
		if ( array_key_exists( $ratio, $sizes ) ) {
			$size = $sizes[ $ratio ];
		}
		if($ratio === '3x2'){
			$class = "size-2x";
		}else{
			$class = "";
		}
		if($i == 2){
			continue;
		}
		?>
		<div class="grid-item <?php echo $class; ?>">
			<div class="item-image">
				<a href="<?php echo esc_url($img['image']['url']); ?>" class="wrap-image js-show-gallery">
					<?php
					thim_elementor_get_attachment_image( $img['image']['id'], $size );
					?>
				</a>

				<div class="wrap-text">
					<?php
					if(!empty($img_title)):
						?>
						<h4 class="title-item">
							<?php echo esc_html($img_title); ?>
						</h4>
					<?php
					endif;
					?>

					<?php
					if(!empty($img_subtitle)):
						?>
						<div class="description-item">
							<?php echo esc_html($img_subtitle); ?>
						</div>
					<?php
					endif;
					?>
				</div>
			</div>
		</div>
		<?php
	}
	?>

</div>
