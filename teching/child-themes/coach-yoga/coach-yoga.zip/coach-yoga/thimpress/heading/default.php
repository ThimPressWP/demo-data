<?php

/**
 * Template for displaying default template Heading element.
 *
 * This template can be overridden by copying it to yourtheme/thimpress/heading/heading.php.
 *
 * @author      ThimPress
 * @package     Thimpress/Templates
 * @version     1.0.0
 * @author      Thimpress, leehld
 */

/**
 * Prevent loading this file directly
 */
defined('ABSPATH') || exit;
?>
<?php if( $instance['style'] == 'style-1' && ! empty($instance['subtitle']) ){?>
	<h5 <?php echo $attribute['subtitle']; ?>><?php echo $instance['subtitle'];?></h5>
<?php } ?>

<?php if( ! empty($instance['title']) ){?>
	<h3 <?php echo $attribute['title']; ?>>
		<?php
		if ( ! empty($instance['link']['url']) ){
			?>
			<a <?php echo $attribute['url'];?>><?php echo $instance['title'];?></a>
		<?php }else{ ?>
			<?php echo $instance['title'];?>
		<?php } ?>
	</h3>
<?php } ?>

<?php if( $instance['style'] == 'default' && ! empty($instance['subtitle']) ){?>
	<h5 <?php echo $attribute['subtitle']; ?>><?php echo $instance['subtitle'];?></h5>
<?php } ?>

<?php if( ! empty($instance['description']) ){?>
	<p <?php echo $attribute['description']; ?>><?php echo $instance['description'];?></p>
<?php } ?>
